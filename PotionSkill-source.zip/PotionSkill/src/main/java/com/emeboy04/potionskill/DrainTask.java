package com.emeboy04.potionskill;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;

/**
 * Skill DRAIN: setelah diaktifkan (Shift+F), air & lava di sekitar player hilang
 * otomatis selama "drain-duration-seconds" detik, tanpa bucket.
 * Task ini berjalan berulang (drain-interval-ticks) dan hanya memproses player yang sedang aktif.
 */
public class DrainTask implements Runnable {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;
    private final SkillAnimations animations;

    public DrainTask(PotionSkillPlugin plugin, SkillManager manager, SkillAnimations animations) {
        this.plugin = plugin;
        this.manager = manager;
        this.animations = animations;
    }

    @Override
    public void run() {
        long now = System.currentTimeMillis();

        for (Map.Entry<UUID, Long> entry : new ArrayList<>(manager.getActiveDrains().entrySet())) {
            UUID id = entry.getKey();
            Player player = plugin.getServer().getPlayer(id);
            if (player == null || !player.isOnline()) {
                manager.stopDrain(id);
                continue;
            }

            Skill skill = manager.getPlayerSkill(id);
            if (skill == null || skill.type() != Skill.Type.DRAIN || manager.getEnergy(id) <= 0) {
                manager.stopDrain(id); // skill berganti / hilang
                continue;
            }

            if (now >= entry.getValue()) {
                manager.stopDrain(id);
                player.sendActionBar(plugin.msg("drain-ended", "%skill%", skill.displayName()));
                continue;
            }

            drainAround(player);
            animations.drainAura(player, drainRadius());
        }
    }

    private int drainRadius() {
        return Math.max(1, Math.min(plugin.getConfig().getInt("drain-radius", 3), 8));
    }

    /** Hilangkan air & lava di sekitar player (sekali jalan). */
    public void drainAround(Player player) {
        FileConfiguration cfg = plugin.getConfig();
        if (cfg.getStringList("drain-disabled-worlds").contains(player.getWorld().getName())) return;
        if (player.getGameMode() == GameMode.SPECTATOR) return;

        int radius = Math.max(1, Math.min(cfg.getInt("drain-radius", 3), 8));
        boolean water = cfg.getBoolean("drain-water", true);
        boolean lava = cfg.getBoolean("drain-lava", true);

        World world = player.getWorld();
        Location center = player.getLocation();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();
        int minY = world.getMinHeight();
        int maxY = world.getMaxHeight() - 1;
        double r2 = (radius + 0.5) * (radius + 0.5);
        int pops = 0; // batasi jumlah animasi per sekali jalan supaya tidak lag

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x * x + y * y + z * z > r2) continue;

                    int by = cy + y;
                    if (by < minY || by > maxY) continue;

                    Block block = world.getBlockAt(cx + x, by, cz + z);
                    Material type = block.getType();

                    if (water && isWaterBlock(type)) {
                        block.setType(Material.AIR, false);
                        if (pops++ < 15) animations.drainPop(block.getLocation().add(0.5, 0.5, 0.5), false);
                    } else if (lava && type == Material.LAVA) {
                        block.setType(Material.AIR, false);
                        if (pops++ < 15) animations.drainPop(block.getLocation().add(0.5, 0.5, 0.5), true);
                    } else if (water) {
                        // blok yang berisi air (tangga, slab, pagar, dll)
                        BlockData data = block.getBlockData();
                        if (data instanceof Waterlogged wl && wl.isWaterlogged()) {
                            wl.setWaterlogged(false);
                            block.setBlockData(wl, false);
                        }
                    }
                }
            }
        }
    }

    private boolean isWaterBlock(Material type) {
        return type == Material.WATER
                || type == Material.BUBBLE_COLUMN
                || type == Material.KELP
                || type == Material.KELP_PLANT
                || type == Material.SEAGRASS
                || type == Material.TALL_SEAGRASS;
    }
}
