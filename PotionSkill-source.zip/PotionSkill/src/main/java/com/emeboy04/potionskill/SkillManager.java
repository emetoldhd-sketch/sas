package com.emeboy04.potionskill;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class SkillManager {

    private final PotionSkillPlugin plugin;
    private final Map<String, Skill> skills = new LinkedHashMap<>();
    private final Map<UUID, String> assigned = new HashMap<>();
    private final Map<UUID, Integer> energy = new HashMap<>();
    /** owner -> daftar player yang dipercayai (skill owner tidak mengenai mereka). */
    private final Map<UUID, Set<UUID>> trusted = new HashMap<>();
    /** Player yang skill Drain-nya sedang aktif -> waktu berakhir (millis). */
    private final Map<UUID, Long> activeDrains = new HashMap<>();
    private final File dataFile;
    private YamlConfiguration data;

    public SkillManager(PotionSkillPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "players.yml");
    }

    /** Muat skill dari config.yml dan data player dari players.yml. */
    public void load() {
        plugin.reloadConfig();
        skills.clear();
        assigned.clear();
        energy.clear();
        trusted.clear();

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("skills");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(id);
                if (s == null) continue;

                String display = s.getString("display-name", id);
                List<PotionEffect> effects = new ArrayList<>();

                for (String line : s.getStringList("effects")) {
                    PotionEffect effect = parseEffect(line);
                    if (effect == null) {
                        plugin.getLogger().warning("Effect tidak valid di skill '" + id + "': " + line);
                    } else {
                        effects.add(effect);
                    }
                }

                String typeName = s.getString("type", "debuff");
                Skill.Type type = "pull".equalsIgnoreCase(typeName) ? Skill.Type.PULL
                        : "drain".equalsIgnoreCase(typeName) ? Skill.Type.DRAIN : Skill.Type.DEBUFF;
                int cooldown = Math.max(0, s.getInt("cooldown-seconds", 0));
                double pullStrength = s.getDouble("pull-strength", 1.3);

                if (type == Skill.Type.DEBUFF && effects.isEmpty()) {
                    plugin.getLogger().warning("Skill '" + id + "' dilewati (tidak ada effect valid).");
                    continue;
                }
                String key = id.toLowerCase(Locale.ROOT);
                skills.put(key, new Skill(key, display, type, effects, cooldown, pullStrength));
            }
        }

        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection players = data.getConfigurationSection("players");
        if (players != null) {
            for (String uuid : players.getKeys(false)) {
                try {
                    assigned.put(UUID.fromString(uuid), players.getString(uuid));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        ConfigurationSection en = data.getConfigurationSection("energy");
        if (en != null) {
            for (String uuid : en.getKeys(false)) {
                try {
                    energy.put(UUID.fromString(uuid), en.getInt(uuid));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        ConfigurationSection tr = data.getConfigurationSection("trust");
        if (tr != null) {
            for (String owner : tr.getKeys(false)) {
                try {
                    UUID ownerId = UUID.fromString(owner);
                    Set<UUID> set = new LinkedHashSet<>();
                    for (String s : tr.getStringList(owner)) {
                        try {
                            set.add(UUID.fromString(s));
                        } catch (IllegalArgumentException ignored) {
                        }
                    }
                    if (!set.isEmpty()) trusted.put(ownerId, set);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    /** Format: "nama_effect:durasi_detik:level" */
    private PotionEffect parseEffect(String line) {
        String[] p = line.split(":");
        if (p.length < 1) return null;
        try {
            NamespacedKey key = NamespacedKey.minecraft(p[0].trim().toLowerCase(Locale.ROOT));
            PotionEffectType type = Registry.POTION_EFFECT_TYPE.get(key);
            if (type == null) return null;

            int seconds = p.length > 1 ? Integer.parseInt(p[1].trim()) : 10;
            int amplifier = p.length > 2 ? Integer.parseInt(p[2].trim()) : 0;
            return new PotionEffect(type, seconds * 20, amplifier, false, true, true);
        } catch (Exception e) {
            return null;
        }
    }

    public void save() {
        if (data == null) data = new YamlConfiguration();
        data.set("players", null);
        for (Map.Entry<UUID, String> e : assigned.entrySet()) {
            data.set("players." + e.getKey(), e.getValue());
        }
        data.set("energy", null);
        for (Map.Entry<UUID, Integer> e : energy.entrySet()) {
            data.set("energy." + e.getKey(), e.getValue());
        }
        data.set("trust", null);
        for (Map.Entry<UUID, Set<UUID>> e : trusted.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            List<String> list = new ArrayList<>();
            for (UUID u : e.getValue()) list.add(u.toString());
            data.set("trust." + e.getKey(), list);
        }
        try {
            plugin.getDataFolder().mkdirs();
            data.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().severe("Gagal menyimpan players.yml: " + ex.getMessage());
        }
    }

    public Map<String, Skill> getSkills() {
        return skills;
    }

    public Skill getSkill(String id) {
        if (id == null) return null;
        String key = id.toLowerCase(Locale.ROOT);
        if (key.equals("auto_drain")) key = "drain"; // nama lama
        return skills.get(key);
    }

    public Skill getPlayerSkill(UUID uuid) {
        return getSkill(assigned.get(uuid));
    }

    public boolean hasSkill(UUID uuid) {
        return getPlayerSkill(uuid) != null;
    }

    public void setSkill(UUID uuid, Skill skill) {
        assigned.put(uuid, skill.id());
        save();
    }

    /** Cooldown skill (detik): milik skill sendiri, atau global kalau tidak diatur. */
    public int getCooldownSeconds(Skill skill) {
        return skill.cooldownSeconds() > 0
                ? skill.cooldownSeconds()
                : plugin.getConfig().getInt("cooldown-seconds", 30);
    }

    // ===== TRUST =====

    /** Apakah owner mempercayai other (skill owner tidak boleh mengenai other)? */
    public boolean isTrusted(UUID owner, UUID other) {
        Set<UUID> set = trusted.get(owner);
        return set != null && set.contains(other);
    }

    public boolean addTrust(UUID owner, UUID other) {
        boolean added = trusted.computeIfAbsent(owner, k -> new LinkedHashSet<>()).add(other);
        if (added) save();
        return added;
    }

    public boolean removeTrust(UUID owner, UUID other) {
        Set<UUID> set = trusted.get(owner);
        if (set == null || !set.remove(other)) return false;
        if (set.isEmpty()) trusted.remove(owner);
        save();
        return true;
    }

    public Set<UUID> getTrusted(UUID owner) {
        Set<UUID> set = trusted.get(owner);
        return set == null ? new LinkedHashSet<>() : new LinkedHashSet<>(set);
    }

    // ===== DRAIN AKTIF =====

    public void activateDrain(UUID id, long untilMillis) {
        activeDrains.put(id, untilMillis);
    }

    public void stopDrain(UUID id) {
        activeDrains.remove(id);
    }

    public Map<UUID, Long> getActiveDrains() {
        return activeDrains;
    }

    // ===== ENERGI =====

    public int getMaxEnergy() {
        return Math.max(1, plugin.getConfig().getInt("max-energy", 5));
    }

    /** Energi player. Player yang belum tercatat dianggap penuh. */
    public int getEnergy(UUID uuid) {
        return Math.max(0, Math.min(energy.getOrDefault(uuid, getMaxEnergy()), getMaxEnergy()));
    }

    public void setEnergy(UUID uuid, int value) {
        energy.put(uuid, Math.max(0, Math.min(value, getMaxEnergy())));
        save();
    }

    /** Acak ulang skill, usahakan hasilnya berbeda dari skill sekarang. */
    public Skill rerollDifferent(UUID uuid) {
        if (skills.isEmpty()) return null;
        String current = assigned.get(uuid);

        List<Skill> pool = new ArrayList<>();
        for (Skill s : skills.values()) {
            if (!s.id().equalsIgnoreCase(current)) pool.add(s);
        }
        if (pool.isEmpty()) pool.addAll(skills.values());

        Skill skill = pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
        setSkill(uuid, skill);
        return skill;
    }

    /** Beri skill acak. */
    public Skill assignRandom(UUID uuid) {
        if (skills.isEmpty()) return null;
        List<Skill> list = new ArrayList<>(skills.values());
        Skill skill = list.get(ThreadLocalRandom.current().nextInt(list.size()));
        setSkill(uuid, skill);
        return skill;
    }
}
