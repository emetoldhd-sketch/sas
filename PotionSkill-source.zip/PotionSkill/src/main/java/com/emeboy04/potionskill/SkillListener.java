package com.emeboy04.potionskill;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.block.Block;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SkillListener implements Listener {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;
    private final DrainTask drainTask;
    private final RerollBook rerollBook;
    private final SkillAnimations animations;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public SkillListener(PotionSkillPlugin plugin, SkillManager manager, DrainTask drainTask,
                         RerollBook rerollBook, SkillAnimations animations) {
        this.plugin = plugin;
        this.manager = manager;
        this.drainTask = drainTask;
        this.rerollBook = rerollBook;
        this.animations = animations;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getConfig().getBoolean("assign-on-join", true)) return;

        if (!manager.hasSkill(player.getUniqueId())) {
            Skill skill = manager.assignRandom(player.getUniqueId());
            if (skill != null) {
                manager.setEnergy(player.getUniqueId(), manager.getMaxEnergy());
                animations.playReroll(player);
                player.sendMessage(plugin.msg("assigned",
                        "%skill%", skill.displayName(),
                        "%energy%", String.valueOf(manager.getEnergy(player.getUniqueId())),
                        "%max%", String.valueOf(manager.getMaxEnergy())));
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cooldowns.remove(event.getPlayer().getUniqueId());
        manager.stopDrain(event.getPlayer().getUniqueId());
    }

    /**
     * Saat ada player mati:
     *  - korban (yang dibunuh) kehilangan energi, kalau 0 -> skill hilang
     *  - pembunuh (player lain) dapat energi, skill kembali kalau tadinya hilang
     */
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        boolean byPlayer = killer != null && !killer.getUniqueId().equals(victim.getUniqueId());
        boolean anyDeath = plugin.getConfig().getBoolean("lose-energy-on-any-death", false);

        if (byPlayer || anyDeath) {
            loseEnergy(victim, byPlayer ? killer.getName() : null);
        }
        if (byPlayer) {
            gainEnergy(killer, victim);
        }
    }

    private void loseEnergy(Player victim, String killerName) {
        UUID id = victim.getUniqueId();
        int current = manager.getEnergy(id);
        if (current <= 0) return; // sudah habis

        int loss = Math.max(1, plugin.getConfig().getInt("energy-loss-per-death", 1));
        int now = Math.max(0, current - loss);
        manager.setEnergy(id, now);
        animations.playEnergyLoss(victim.getLocation());

        victim.sendMessage(plugin.msg("energy-lost",
                "%loss%", String.valueOf(current - now),
                "%energy%", String.valueOf(now),
                "%max%", String.valueOf(manager.getMaxEnergy()),
                "%killer%", killerName == null ? "-" : killerName));

        if (now <= 0) {
            animations.playSkillLost(victim.getLocation());
            Skill skill = manager.getPlayerSkill(id);
            victim.sendMessage(plugin.msg("skill-lost",
                    "%skill%", skill == null ? "" : skill.displayName()));
        }
    }

    private void gainEnergy(Player killer, Player victim) {
        UUID id = killer.getUniqueId();
        int max = manager.getMaxEnergy();
        int current = manager.getEnergy(id);

        if (current >= max) {
            killer.sendActionBar(plugin.msg("energy-full",
                    "%energy%", String.valueOf(current),
                    "%max%", String.valueOf(max)));
            return;
        }

        int gain = Math.max(1, plugin.getConfig().getInt("energy-per-kill", 1));
        int now = Math.min(max, current + gain);
        manager.setEnergy(id, now);

        killer.sendActionBar(plugin.msg("energy-gain",
                "%gain%", String.valueOf(now - current),
                "%energy%", String.valueOf(now),
                "%max%", String.valueOf(max),
                "%victim%", victim.getName()));
        animations.playEnergyGain(killer);

        Skill skill = manager.getPlayerSkill(id);
        if (current <= 0 && skill != null) {
            animations.playSkillBack(killer);
            killer.sendMessage(plugin.msg("skill-back", "%skill%", skill.displayName()));
        }
    }

    /** Klik kanan sambil memegang Reroll Book -> skill diacak ulang, buku habis 1. */
    @EventHandler
    public void onUseRerollBook(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!rerollBook.isRerollBook(hand)) return;

        // klik blok yang bisa dibuka (chest, pintu, dll): biarkan normal, kecuali sambil Shift
        if (action == Action.RIGHT_CLICK_BLOCK) {
            Block clicked = event.getClickedBlock();
            if (clicked != null && clicked.getType().isInteractable() && !player.isSneaking()) return;
        }

        event.setCancelled(true);

        if (!player.hasPermission("potionskill.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }

        Skill skill = manager.rerollDifferent(player.getUniqueId());
        if (skill == null) {
            player.sendMessage(plugin.msg("reroll-no-skills"));
            return;
        }

        if (hand.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }

        animations.playReroll(player);
        player.sendMessage(plugin.msg("reroll-used", "%skill%", skill.displayName()));
    }

    /** Skill PULL (KB Back): saat memukul player, player itu ditarik ke arah kita. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;
        if (attacker.getUniqueId().equals(victim.getUniqueId())) return;

        UUID id = attacker.getUniqueId();
        Skill skill = manager.getPlayerSkill(id);
        if (skill == null || skill.type() != Skill.Type.PULL) return;
        if (!attacker.hasPermission("potionskill.use")) return;
        if (manager.getEnergy(id) <= 0) return; // skill hilang

        GameMode gm = victim.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (plugin.getConfig().getBoolean("ignore-same-team", true) && sameTeam(attacker, victim)) return;
        if (manager.isTrusted(id, victim.getUniqueId())) return; // player yang di-/trust tidak ditarik

        long now = System.currentTimeMillis();
        long readyAt = cooldowns.getOrDefault(id, 0L);
        if (now < readyAt) {
            double secondsLeft = Math.ceil((readyAt - now) / 100.0) / 10.0;
            attacker.sendActionBar(plugin.msg("cooldown", "%time%", String.valueOf(secondsLeft)));
            return;
        }
        cooldowns.put(id, now + manager.getCooldownSeconds(skill) * 1000L);

        // tarik di tick berikutnya supaya tidak ditimpa knockback bawaan Minecraft
        plugin.getServer().getScheduler().runTask(plugin, () -> pull(attacker, victim, skill));
    }

    private void pull(Player attacker, Player victim, Skill skill) {
        if (!attacker.isOnline() || !victim.isOnline() || victim.isDead()) return;
        if (attacker.getWorld() != victim.getWorld()) return;

        Vector dir = attacker.getLocation().toVector().subtract(victim.getLocation().toVector());
        dir.setY(0);
        double dist = dir.length();
        if (dist > 0.8) {
            // jangan sampai melewati kita: kecepatan dibatasi oleh jarak
            double speed = Math.min(skill.pullStrength(), dist * 0.4);
            victim.setVelocity(dir.normalize().multiply(speed).setY(0.2));
        }

        animations.playPull(attacker, victim);

        attacker.sendActionBar(plugin.msg("pull-used",
                "%skill%", skill.displayName(),
                "%victim%", victim.getName()));
        victim.sendActionBar(plugin.msg("pulled", "%player%", attacker.getName()));
    }

    /** Tombol F = swap item ke offhand. Kalau sambil Shift, kita pakai sebagai skill. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();

        if (plugin.getConfig().getBoolean("require-sneak", true) && !player.isSneaking()) {
            return; // F biasa tetap berfungsi normal (tukar item)
        }

        event.setCancelled(true); // cegah item tertukar ke offhand

        if (!player.hasPermission("potionskill.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }

        UUID id = player.getUniqueId();
        Skill skill = manager.getPlayerSkill(id);
        if (skill == null) {
            player.sendMessage(plugin.msg("no-skill"));
            return;
        }

        if (skill.type() == Skill.Type.PULL) {
            player.sendActionBar(plugin.msg("skill-passive", "%skill%", skill.displayName()));
            return;
        }

        int energy = manager.getEnergy(id);
        if (energy <= 0) {
            player.sendActionBar(plugin.msg("no-energy"));
            return;
        }

        long now = System.currentTimeMillis();
        long cooldownMs = manager.getCooldownSeconds(skill) * 1000L;
        long readyAt = cooldowns.getOrDefault(id, 0L);

        if (now < readyAt) {
            double secondsLeft = Math.ceil((readyAt - now) / 100.0) / 10.0;
            player.sendActionBar(plugin.msg("cooldown", "%time%", String.valueOf(secondsLeft)));
            return;
        }

        if (skill.type() == Skill.Type.DRAIN) {
            int seconds = Math.max(1, plugin.getConfig().getInt("drain-duration-seconds", 10));
            cooldowns.put(id, now + cooldownMs);
            manager.activateDrain(id, now + seconds * 1000L);
            drainTask.drainAround(player); // langsung bersihkan sekali
            animations.playDrainStart(player);
            player.sendActionBar(plugin.msg("drain-used",
                    "%skill%", skill.displayName(),
                    "%time%", String.valueOf(seconds)));
            return;
        }

        List<LivingEntity> targets = findTargets(player);
        if (targets.isEmpty()) {
            // tidak ada musuh -> cooldown & energi tidak terpakai
            player.sendActionBar(plugin.msg("no-target"));
            return;
        }

        for (LivingEntity target : targets) {
            for (PotionEffect effect : skill.effects()) {
                target.addPotionEffect(effect);
            }

            animations.playBolt(player, target, skill);
            animations.playHit(target, skill);

            if (target instanceof Player victim) {
                victim.sendActionBar(plugin.msg("hit",
                        "%skill%", skill.displayName(),
                        "%player%", player.getName()));
            }
        }

        cooldowns.put(id, now + cooldownMs);

        animations.playCast(player, skill, plugin.getConfig().getDouble("radius", 8.0));
        player.sendActionBar(plugin.msg("used",
                "%skill%", skill.displayName(),
                "%count%", String.valueOf(targets.size()),
                "%energy%", String.valueOf(energy),
                "%max%", String.valueOf(manager.getMaxEnergy())));
    }

    /** Cari musuh di sekitar player (player lain, dan opsional monster). */
    private List<LivingEntity> findTargets(Player caster) {
        double radius = plugin.getConfig().getDouble("radius", 8.0);
        boolean mobs = plugin.getConfig().getBoolean("affect-hostile-mobs", false);
        boolean ignoreTeam = plugin.getConfig().getBoolean("ignore-same-team", true);

        List<LivingEntity> result = new ArrayList<>();
        Location center = caster.getLocation();

        for (Entity e : caster.getNearbyEntities(radius, radius, radius)) {
            if (e.getWorld() != center.getWorld()) continue;
            if (e.getLocation().distanceSquared(center) > radius * radius) continue;

            if (e instanceof Player target) {
                if (target.getUniqueId().equals(caster.getUniqueId())) continue;
                GameMode gm = target.getGameMode();
                if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) continue;
                if (ignoreTeam && sameTeam(caster, target)) continue;
                if (manager.isTrusted(caster.getUniqueId(), target.getUniqueId())) continue;
                result.add(target);
            } else if (mobs && e instanceof Monster monster) {
                result.add(monster);
            }
        }
        return result;
    }

    private boolean sameTeam(Player a, Player b) {
        Team team = a.getScoreboard().getEntryTeam(a.getName());
        return team != null && team.hasEntry(b.getName());
    }
}
