package com.emeboy04.potionskill;

import org.bukkit.potion.PotionEffect;

import java.util.List;

/**
 * Satu skill.
 *  - DEBUFF : Shift+F memberi potion effect buruk ke musuh sekitar
 *  - PULL   : pasif, saat memukul player -> player itu ditarik ke arah kita
 *  - DRAIN  : pasif, air & lava di sekitar player hilang otomatis (tanpa bucket)
 *
 * cooldownSeconds = 0 berarti pakai cooldown global dari config.
 */
public record Skill(String id, String displayName, Type type, List<PotionEffect> effects,
                    int cooldownSeconds, double pullStrength) {

    public enum Type {
        DEBUFF, PULL, DRAIN
    }
}
