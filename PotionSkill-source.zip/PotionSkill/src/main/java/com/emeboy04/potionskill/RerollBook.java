package com.emeboy04.potionskill;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * Reroll Book: item yang bisa di-craft (6 Diamond Block + 3 Netherite Ingot, bebas susunan).
 * Klik kanan sambil memegangnya -> skill diacak ulang, buku habis 1.
 */
public class RerollBook {

    private final PotionSkillPlugin plugin;
    private final NamespacedKey itemKey;
    private final NamespacedKey recipeKey;

    public RerollBook(PotionSkillPlugin plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "reroll_book");
        this.recipeKey = new NamespacedKey(plugin, "reroll_book_recipe");
    }

    public ItemStack create(int amount) {
        ItemStack item = new ItemStack(Material.BOOK, Math.max(1, Math.min(amount, 64)));
        ItemMeta meta = item.getItemMeta();

        String name = plugin.getConfig().getString("reroll-book.name", "&6&lReroll Book");
        meta.displayName(PotionSkillPlugin.color(name).decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("reroll-book.lore")) {
            lore.add(PotionSkillPlugin.color(line).decoration(TextDecoration.ITALIC, false));
        }
        if (!lore.isEmpty()) meta.lore(lore);

        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isRerollBook(ItemStack item) {
        if (item == null || item.getType() != Material.BOOK || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    /** Resep: 6 Diamond Block + 3 Netherite Ingot (susunan bebas di crafting table). */
    public void registerRecipe() {
        Bukkit.removeRecipe(recipeKey); // jaga-jaga kalau sudah terdaftar (reload)

        ShapelessRecipe recipe = new ShapelessRecipe(recipeKey, create(1));
        recipe.addIngredient(6, Material.DIAMOND_BLOCK);
        recipe.addIngredient(3, Material.NETHERITE_INGOT);
        Bukkit.addRecipe(recipe);
    }

    public void unregisterRecipe() {
        Bukkit.removeRecipe(recipeKey);
    }
}
