package com.emeboy04.potionskill;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * /trust <player>          -> skillmu tidak akan mengenai player itu
 * /trust remove <player>   -> cabut kepercayaan (atau /untrust <player>)
 * /trust list              -> lihat daftar
 *
 * Trust berlaku satu arah: hanya melindungi player yang kamu percayai dari SKILLMU.
 * Supaya saling aman, kedua pihak harus saling /trust.
 */
public class TrustCommand implements CommandExecutor, TabCompleter {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;

    public TrustCommand(PotionSkillPlugin plugin, SkillManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    private void send(CommandSender to, String text) {
        to.sendMessage(PotionSkillPlugin.color(plugin.getConfig().getString("messages.prefix", "") + text));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            send(sender, "&cHanya untuk player.");
            return true;
        }

        boolean untrust = command.getName().equalsIgnoreCase("untrust");

        if (args.length == 0) {
            help(player, untrust);
            return true;
        }

        String first = args[0].toLowerCase(Locale.ROOT);

        if (!untrust && first.equals("list")) {
            list(player);
            return true;
        }

        if (untrust || first.equals("remove") || first.equals("del")) {
            String name = untrust ? args[0] : (args.length > 1 ? args[1] : null);
            if (name == null) {
                send(player, "&cGunakan: /trust remove <player>");
                return true;
            }
            remove(player, name);
            return true;
        }

        add(player, args[0]);
        return true;
    }

    private void help(Player player, boolean untrust) {
        if (untrust) {
            send(player, "&cGunakan: /untrust <player>");
            return;
        }
        send(player, "&7Skillmu tidak akan mengenai player yang kamu percayai.");
        send(player, "&e/trust <player> &7- percayai player");
        send(player, "&e/trust remove <player> &7(atau &e/untrust&7) - cabut kepercayaan");
        send(player, "&e/trust list &7- lihat daftar");
    }

    private OfflinePlayer resolve(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        return Bukkit.getOfflinePlayerIfCached(name); // player yang pernah join & sudah tercatat
    }

    private String nameOf(UUID uuid) {
        String n = Bukkit.getOfflinePlayer(uuid).getName();
        return n != null ? n : uuid.toString().substring(0, 8);
    }

    private void add(Player player, String name) {
        OfflinePlayer target = resolve(name);
        if (target == null) {
            send(player, "&cPlayer &e" + name + " &ctidak ditemukan.");
            return;
        }

        UUID me = player.getUniqueId();
        UUID other = target.getUniqueId();

        if (other.equals(me)) {
            send(player, "&cKamu tidak bisa mempercayai dirimu sendiri.");
            return;
        }

        String display = target.getName() != null ? target.getName() : name;

        if (manager.isTrusted(me, other)) {
            send(player, "&e" + display + " &csudah ada di daftar trust-mu.");
            return;
        }

        int max = plugin.getConfig().getInt("trust-max", 10);
        if (max > 0 && manager.getTrusted(me).size() >= max) {
            send(player, "&cDaftar trust penuh (maksimal " + max + "). Hapus dulu dengan /untrust.");
            return;
        }

        manager.addTrust(me, other);
        send(player, "&aSkillmu tidak akan mengenai &e" + display + " &alagi.");

        Player online = target.getPlayer();
        if (online != null) {
            send(online, "&e" + player.getName() + " &7mempercayaimu, jadi skillnya tidak akan mengenaimu. "
                    + "Ketik &e/trust " + player.getName() + " &7supaya skillmu juga tidak mengenainya.");
        }
    }

    private void remove(Player player, String name) {
        UUID me = player.getUniqueId();
        UUID found = null;

        for (UUID u : manager.getTrusted(me)) {
            if (nameOf(u).equalsIgnoreCase(name)) {
                found = u;
                break;
            }
        }
        if (found == null) {
            OfflinePlayer r = resolve(name);
            if (r != null && manager.isTrusted(me, r.getUniqueId())) found = r.getUniqueId();
        }
        if (found == null) {
            send(player, "&e" + name + " &ctidak ada di daftar trust-mu.");
            return;
        }

        manager.removeTrust(me, found);
        send(player, "&7Skillmu bisa mengenai &e" + nameOf(found) + " &7lagi.");
    }

    private void list(Player player) {
        Set<UUID> set = manager.getTrusted(player.getUniqueId());
        if (set.isEmpty()) {
            send(player, "&7Daftar trust kosong. Pakai &e/trust <player>&7.");
            return;
        }
        List<String> names = new ArrayList<>();
        for (UUID u : set) names.add(nameOf(u));
        int max = plugin.getConfig().getInt("trust-max", 10);
        send(player, "&aTrust (" + set.size() + (max > 0 ? "/" + max : "") + "): &f" + String.join("&7, &f", names));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!(sender instanceof Player player)) return out;

        boolean untrust = command.getName().equalsIgnoreCase("untrust");

        List<String> trustedNames = new ArrayList<>();
        for (UUID u : manager.getTrusted(player.getUniqueId())) trustedNames.add(nameOf(u));

        if (untrust) {
            if (args.length == 1) out.addAll(trustedNames);
        } else if (args.length == 1) {
            out.add("list");
            out.add("remove");
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.getUniqueId().equals(player.getUniqueId())) out.add(p.getName());
            }
        } else if (args.length == 2
                && (args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("del"))) {
            out.addAll(trustedNames);
        }

        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
