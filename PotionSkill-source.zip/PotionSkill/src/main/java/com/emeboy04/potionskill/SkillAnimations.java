package com.emeboy04.potionskill;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Semua animasi (partikel + suara) skill.
 * Partikel dicari lewat nama, jadi kalau ada nama yang tidak dikenal versi server,
 * partikel itu dilewati saja (tidak error).
 */
public class SkillAnimations {

    /** Tema visual satu skill. */
    private record Theme(String main, String accent, Color color, String castSound, String hitSound) {
    }

    private final PotionSkillPlugin plugin;
    private final Map<String, Theme> themes = new HashMap<>();
    private final Map<String, Optional<Particle>> particleCache = new HashMap<>();
    private final Theme defaultTheme = new Theme("SMOKE", "WITCH", Color.fromRGB(150, 60, 200),
            "entity.evoker.cast_spell", "entity.wither.shoot");

    public SkillAnimations(PotionSkillPlugin plugin) {
        this.plugin = plugin;

        themes.put("freezer", new Theme("SNOWFLAKE", "CLOUD", Color.fromRGB(170, 230, 255),
                "entity.player.hurt_freeze", "block.glass.break"));
        themes.put("blinder", new Theme("SQUID_INK", "LARGE_SMOKE", Color.fromRGB(25, 25, 25),
                "entity.squid.squirt", "entity.squid.squirt"));
        themes.put("poisoner", new Theme("ITEM_SLIME", "DUST", Color.fromRGB(70, 200, 60),
                "entity.splash_potion.break", "entity.slime.squish"));
        themes.put("withering", new Theme("SOUL", "DUST", Color.fromRGB(35, 35, 35),
                "entity.wither.shoot", "entity.wither.hurt"));
        themes.put("sky_lifter", new Theme("CLOUD", "END_ROD", Color.WHITE,
                "entity.ender_dragon.flap", "entity.phantom.flap"));
        themes.put("hexer", new Theme("WITCH", "ENCHANT", Color.fromRGB(150, 50, 200),
                "entity.evoker.cast_spell", "entity.witch.ambient"));
        themes.put("dizzy", new Theme("CRIT", "NOTE", Color.fromRGB(255, 120, 200),
                "block.note_block.chime", "block.note_block.bell"));
        themes.put("spotter", new Theme("GLOW", "END_ROD", Color.fromRGB(255, 230, 80),
                "entity.experience_orb.pickup", "block.beacon.activate"));
        themes.put("starver", new Theme("SMOKE", "WHITE_ASH", Color.fromRGB(140, 90, 40),
                "entity.player.burp", "entity.zombie.ambient"));
        themes.put("curse", new Theme("SOUL_FIRE_FLAME", "WITCH", Color.fromRGB(120, 0, 30),
                "entity.elder_guardian.curse", "entity.wither.ambient"));
        themes.put("kb_back", new Theme("CRIT", "ENCHANTED_HIT", Color.fromRGB(70, 130, 255),
                "entity.fishing_bobber.retrieve", "entity.player.attack.knockback"));
        themes.put("drain", new Theme("SPLASH", "BUBBLE", Color.fromRGB(40, 120, 230),
                "item.bucket.fill", "item.bucket.fill"));
    }

    // ===================== helper =====================

    private boolean enabled() {
        return plugin.getConfig().getBoolean("animations-enabled", true);
    }

    private double density() {
        return Math.max(0.1, Math.min(plugin.getConfig().getDouble("animations-density", 1.0), 3.0));
    }

    private Theme themeFor(Skill skill) {
        return themes.getOrDefault(skill.id(), defaultTheme);
    }

    private Particle particle(String name) {
        if (name == null) return null;
        return particleCache.computeIfAbsent(name, n -> {
            try {
                return Optional.of(Particle.valueOf(n));
            } catch (IllegalArgumentException e) {
                return Optional.empty();
            }
        }).orElse(null);
    }

    private void spawn(World world, Location loc, String name, int count,
                       double ox, double oy, double oz, double extra, Color color) {
        if (world == null) return;
        Particle p = particle(name);
        if (p == null) return;
        int c = Math.max(1, (int) Math.round(count * density()));
        if ("DUST".equals(name)) {
            world.spawnParticle(p, loc, c, ox, oy, oz, extra,
                    new Particle.DustOptions(color == null ? Color.WHITE : color, 1.2f));
        } else {
            world.spawnParticle(p, loc, c, ox, oy, oz, extra);
        }
    }

    private void sound(Location loc, String key, float volume, float pitch) {
        if (loc.getWorld() == null) return;
        loc.getWorld().playSound(loc, key, SoundCategory.PLAYERS, volume, pitch);
    }

    private void ring(Location center, double r, int points, String name, Color color, double yOff) {
        for (int i = 0; i < points; i++) {
            double ang = 2 * Math.PI * i / points;
            Location l = center.clone().add(Math.cos(ang) * r, yOff, Math.sin(ang) * r);
            spawn(center.getWorld(), l, name, 1, 0, 0, 0, 0, color);
        }
    }

    /** Spiral yang naik mengelilingi player. */
    private void spiral(Player p, int ticks, double radius, double height,
                        String a, String b, Color color, String endBurst) {
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead()) {
                    cancel();
                    return;
                }
                if (tick >= ticks) {
                    if (endBurst != null) {
                        spawn(p.getWorld(), p.getLocation().add(0, 1, 0), endBurst, 30, 0.4, 0.7, 0.4, 0.15, color);
                    }
                    cancel();
                    return;
                }
                Location base = p.getLocation();
                double prog = (double) tick / ticks;
                double ang = tick * 0.55;
                for (int k = 0; k < 2; k++) {
                    double aa = ang + k * Math.PI;
                    Location l = base.clone().add(Math.cos(aa) * radius, prog * height, Math.sin(aa) * radius);
                    spawn(p.getWorld(), l, a, 2, 0.02, 0.02, 0.02, 0, color);
                    spawn(p.getWorld(), l, b, 1, 0, 0, 0, 0, color);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ===================== skill DEBUFF (Shift+F) =====================

    /** Animasi di sekitar pemakai: cincin yang melebar + spiral naik. */
    public void playCast(Player caster, Skill skill, double radius) {
        if (!enabled()) return;
        Theme t = themeFor(skill);

        sound(caster.getLocation(), t.castSound(), 1f, 1f);
        spawn(caster.getWorld(), caster.getLocation().add(0, 1, 0), t.main(), 30, 0.5, 0.8, 0.5, 0.1, t.color());

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!caster.isOnline() || tick > 12) {
                    cancel();
                    return;
                }
                Location base = caster.getLocation().add(0, 0.15, 0);
                double r = radius * (tick + 1) / 13.0;
                int points = 20 + tick * 2;
                ring(base, r, points, t.main(), t.color(), 0);
                if (tick % 2 == 0) ring(base, r * 0.85, points / 2, t.accent(), t.color(), 0.2);

                double ang = tick * 0.9;
                for (int i = 0; i < 3; i++) {
                    double a = ang + i * 2.094;
                    Location l = base.clone().add(Math.cos(a), tick * 0.15, Math.sin(a));
                    spawn(caster.getWorld(), l, t.accent(), 1, 0, 0, 0, 0, t.color());
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /** Peluru partikel dari pemakai menuju satu musuh. */
    public void playBolt(Player caster, LivingEntity target, Skill skill) {
        if (!enabled()) return;
        Theme t = themeFor(skill);

        Location from = caster.getLocation().add(0, 1.2, 0);
        Location to = target.getLocation().add(0, 1.0, 0);
        Vector dir = to.toVector().subtract(from.toVector());
        double len = dir.length();
        if (len < 0.5) return;
        Vector step = dir.normalize();
        World world = from.getWorld();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (tick > 6) {
                    cancel();
                    return;
                }
                double head = len * (tick + 1) / 7.0;
                for (double d = Math.max(0, head - len / 7.0); d <= head; d += 0.4) {
                    Location l = from.clone().add(step.clone().multiply(d));
                    spawn(world, l, t.main(), 1, 0.05, 0.05, 0.05, 0, t.color());
                    if (tick % 2 == 0) spawn(world, l, t.accent(), 1, 0.05, 0.05, 0.05, 0, t.color());
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /** Ledakan partikel di korban + aura yang berputar sekitar 1,5 detik. */
    public void playHit(LivingEntity target, Skill skill) {
        if (!enabled()) return;
        Theme t = themeFor(skill);

        Location c = target.getLocation().add(0, 1.0, 0);
        spawn(c.getWorld(), c, t.main(), 25, 0.35, 0.6, 0.35, 0.03, t.color());
        spawn(c.getWorld(), c, t.accent(), 12, 0.35, 0.6, 0.35, 0.05, t.color());
        sound(c, t.hitSound(), 0.8f, 1.1f);

        boolean overHead = "dizzy".equals(skill.id()); // bintang berputar di kepala

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!target.isValid() || target.isDead() || tick >= 30) {
                    cancel();
                    return;
                }
                Location l = target.getLocation();
                double ang = tick * 0.6;
                for (int k = 0; k < 2; k++) {
                    double aa = ang + k * Math.PI;
                    double h = overHead ? 1.9 : 0.1 + (tick % 15) * 0.12;
                    Location p = l.clone().add(Math.cos(aa) * 0.6, h, Math.sin(aa) * 0.6);
                    spawn(l.getWorld(), p, t.accent(), 1, 0, 0, 0, 0, t.color());
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ===================== skill PULL (KB Back) =====================

    /** Tali partikel dari penyerang ke korban + jejak saat korban tertarik. */
    public void playPull(Player attacker, Player victim) {
        if (!enabled()) return;
        Theme t = themes.getOrDefault("kb_back", defaultTheme);

        Location from = attacker.getLocation().add(0, 1.2, 0);
        Location to = victim.getLocation().add(0, 1.0, 0);
        Vector dir = to.toVector().subtract(from.toVector());
        double len = dir.length();
        if (len > 0.3) {
            Vector step = dir.clone().normalize();
            int i = 0;
            for (double d = 0; d <= len; d += 0.35) {
                Location l = from.clone().add(step.clone().multiply(d));
                spawn(from.getWorld(), l, t.main(), 1, 0.03, 0.03, 0.03, 0, t.color());
                if (i++ % 2 == 0) spawn(from.getWorld(), l, "DUST", 1, 0, 0, 0, 0, t.color());
            }
        }

        spawn(to.getWorld(), to, t.accent(), 15, 0.3, 0.5, 0.3, 0.1, t.color());
        sound(victim.getLocation(), t.castSound(), 1f, 1f);
        sound(victim.getLocation(), t.hitSound(), 0.8f, 1f);
        sound(attacker.getLocation(), t.castSound(), 1f, 1.2f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!victim.isOnline() || victim.isDead() || tick >= 10) {
                    cancel();
                    return;
                }
                Location l = victim.getLocation().add(0, 0.3, 0);
                spawn(l.getWorld(), l, "CLOUD", 3, 0.2, 0.1, 0.2, 0.01, t.color());
                spawn(l.getWorld(), l.clone().add(0, 0.7, 0), t.main(), 2, 0.25, 0.4, 0.25, 0.02, t.color());
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ===================== skill DRAIN =====================

    /** Saat Drain diaktifkan: pusaran air menyempit ke arah pemakai. */
    public void playDrainStart(Player p) {
        if (!enabled()) return;
        Theme t = themes.getOrDefault("drain", defaultTheme);
        sound(p.getLocation(), t.castSound(), 1f, 1f);

        double radius = Math.max(1, Math.min(plugin.getConfig().getInt("drain-radius", 3), 8));
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!p.isOnline() || tick > 15) {
                    cancel();
                    return;
                }
                Location base = p.getLocation().add(0, 0.2, 0);
                double r = radius * (1.2 - 0.9 * tick / 15.0);
                double ang = tick * 0.5;
                for (int i = 0; i < 4; i++) {
                    double a = ang + i * Math.PI / 2;
                    double h = (tick % 8) * 0.2;
                    Location l = base.clone().add(Math.cos(a) * r, h, Math.sin(a) * r);
                    spawn(p.getWorld(), l, t.main(), 2, 0.05, 0.05, 0.05, 0, t.color());
                    spawn(p.getWorld(), l, "DUST", 1, 0, 0, 0, 0, t.color());
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /** Aura berputar selama Drain aktif (dipanggil berulang oleh DrainTask). */
    public void drainAura(Player p, int radius) {
        if (!enabled()) return;
        Theme t = themes.getOrDefault("drain", defaultTheme);

        long time = System.currentTimeMillis() / 50;
        Location base = p.getLocation();
        for (int i = 0; i < 10; i++) {
            double a = time * 0.35 + i * (2 * Math.PI / 10);
            Location low = base.clone().add(Math.cos(a) * radius * 0.9, 0.15, Math.sin(a) * radius * 0.9);
            Location mid = base.clone().add(Math.cos(-a) * radius * 0.6, 1.0, Math.sin(-a) * radius * 0.6);
            spawn(p.getWorld(), low, t.main(), 1, 0, 0, 0, 0, t.color());
            if (i % 2 == 0) spawn(p.getWorld(), mid, t.accent(), 1, 0, 0, 0, 0, t.color());
        }
    }

    /** Percikan kecil di blok air/lava yang baru dihilangkan. */
    public void drainPop(Location center, boolean lava) {
        if (!enabled()) return;
        if (lava) {
            spawn(center.getWorld(), center, "LARGE_SMOKE", 3, 0.25, 0.25, 0.25, 0.02, null);
            spawn(center.getWorld(), center, "LAVA", 2, 0.25, 0.25, 0.25, 0, null);
        } else {
            spawn(center.getWorld(), center, "SPLASH", 6, 0.25, 0.25, 0.25, 0.05, null);
            spawn(center.getWorld(), center, "BUBBLE", 3, 0.25, 0.25, 0.25, 0.05, null);
        }
    }

    // ===================== reroll & energi =====================

    /** Reroll Book dipakai / dapat skill pertama kali. */
    public void playReroll(Player p) {
        if (!enabled()) return;
        sound(p.getLocation(), "block.enchantment_table.use", 1f, 1f);
        sound(p.getLocation(), "entity.player.levelup", 0.7f, 1.4f);
        spiral(p, 24, 0.9, 2.2, "ENCHANT", "END_ROD", Color.fromRGB(255, 200, 60), "TOTEM_OF_UNDYING");
    }

    /** +energi karena membunuh player. */
    public void playEnergyGain(Player p) {
        if (!enabled()) return;
        sound(p.getLocation(), "entity.player.levelup", 1f, 1.2f);
        spiral(p, 12, 0.7, 1.8, "HAPPY_VILLAGER", "ENCHANT", Color.fromRGB(80, 220, 80), null);
    }

    /** Skill kembali setelah sempat hilang. */
    public void playSkillBack(Player p) {
        if (!enabled()) return;
        sound(p.getLocation(), "item.totem.use", 0.6f, 1.3f);
        spiral(p, 20, 1.0, 2.4, "TOTEM_OF_UNDYING", "END_ROD", Color.fromRGB(255, 220, 80), "FIREWORK");
    }

    /** -energi karena dibunuh. */
    public void playEnergyLoss(Location loc) {
        if (!enabled()) return;
        spawn(loc.getWorld(), loc.clone().add(0, 1, 0), "SOUL", 10, 0.3, 0.6, 0.3, 0.03, null);
        sound(loc, "particle.soul_escape", 1f, 1f);
    }

    /** Energi habis -> skill hilang. */
    public void playSkillLost(Location loc) {
        if (!enabled()) return;
        Location c = loc.clone().add(0, 1, 0);
        spawn(loc.getWorld(), c, "SOUL", 30, 0.4, 0.8, 0.4, 0.05, null);
        spawn(loc.getWorld(), c, "SMOKE", 20, 0.4, 0.8, 0.4, 0.05, null);
        sound(loc, "entity.wither.death", 0.4f, 1.5f);
        sound(loc, "block.glass.break", 1f, 0.8f);
    }
}
