# PotionSkill (Paper 1.21.11)

Setiap player otomatis dapat 1 skill acak saat pertama join.
Tekan **Shift + F** untuk memberi potion effect BURUK ke semua musuh di sekitar (radius di config), ada cooldown.

## Build
Butuh Java 21 + Maven:

    mvn clean package

Hasil: `target/PotionSkill-1.0.0.jar` -> taruh di folder `plugins/` server Paper 1.21.11.

## Trust (anti kena team)
- `/trust <player>` skillmu tidak akan mengenai player itu (juga tidak menarik dengan KB Back)
- `/trust remove <player>` atau `/untrust <player>` cabut kepercayaan
- `/trust list` lihat daftar
Berlaku satu arah: agar saling aman, kedua pihak harus saling /trust. Maksimal diatur `trust-max`.

## Animasi
Setiap skill punya animasi partikel + suara sendiri (cincin yang melebar, peluru ke musuh, aura di korban,
tali tarikan KB Back, pusaran air Drain, spiral Reroll Book, efek energi). Atur di config:
`animations-enabled` dan `animations-density`.

## Skill KB Back
Skill pasif: saat kamu memukul player, player itu ditarik ke arahmu. Cooldown 200 detik (atur di config).

## Skill Drain
Skill aktif (Shift + F): air & lava di sekitarmu hilang otomatis selama 10 detik tanpa bucket. Cooldown 50 detik.

## Reroll Book
Craft di crafting table: 6 Diamond Block + 3 Netherite Ingot (susunan bebas).
Klik kanan sambil memegang bukunya -> skill diacak ulang (buku habis 1). Admin: `/pskill givebook <player> [jumlah]`.

## Energi
- Setiap player punya **5 energi** (bisa diubah di config).
- Memakai skill TIDAK memakai energi.
- Setiap kali kamu **dibunuh** player lain: -1 energi.
- Energi habis (0) = **skill hilang**.
- Kamu **membunuh** player lain: +1 energi, skill kembali.

## Perintah
- /pskill info            -> lihat skill kamu
- /pskill list            -> daftar semua skill
- /pskill set <player> <skill>  (admin)
- /pskill energy <player> <jumlah> (admin)
- /pskill reroll [player]       (admin)
- /pskill reload                (admin)

Permission: `potionskill.use` (default semua), `potionskill.admin` (default op).
Edit skill, effect, durasi, level, dan cooldown di `plugins/PotionSkill/config.yml`.
